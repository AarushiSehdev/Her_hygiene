package com.example.her_hygiene

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
